const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const nodemailer = require('nodemailer');
require('dotenv').config();

const app = express();
app.use(cors());
app.use(express.json());

mongoose.connect(process.env.MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true });

const bookingSchema = new mongoose.Schema({
  name: String,
  phone: String,
  date: String,
  eventType: String,
  guests: String,
  notes: String
});

const Booking = mongoose.model("Booking", bookingSchema);

app.post('/api/bookings', async (req, res) => {
  const booking = new Booking(req.body);
  await booking.save();

  // Send email to owner
  const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
      user: process.env.EMAIL_USER,
      pass: process.env.EMAIL_PASS
    }
  });

  const mailOptions = {
    from: process.env.EMAIL_USER,
    to: process.env.EMAIL_USER,
    subject: 'New Catering Booking',
    text: `
New Booking Received:

Name: ${req.body.name}
Phone: ${req.body.phone}
Date: ${req.body.date}
Event Type: ${req.body.eventType}
Guests: ${req.body.guests}
Notes: ${req.body.notes}
    `
  };

  transporter.sendMail(mailOptions, (error, info) => {
    if (error) return res.status(500).send(error.toString());
    res.status(200).send("Booking saved and email sent.");
  });
});

app.listen(5000, () => console.log("Server running on port 5000"));

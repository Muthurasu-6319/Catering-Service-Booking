import { Link } from "react-router-dom";

function Home() {
  return (
    <div className="min-h-screen bg-gray-100 flex flex-col items-center justify-center text-center p-4">
      <h1 className="text-4xl font-bold mb-4">Dhanabalan Catering Services</h1>
      <p className="text-lg mb-6">Delicious food for all your occasions</p>
      <Link to="/booking">
        <button className="bg-green-600 text-white px-6 py-2 rounded-lg shadow-md hover:bg-green-700 transition">
          Book Now
        </button>
      </Link>
    </div>
  );
}

export default Home;
